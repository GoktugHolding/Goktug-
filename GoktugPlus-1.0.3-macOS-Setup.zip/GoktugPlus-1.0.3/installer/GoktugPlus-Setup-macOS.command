#!/usr/bin/env bash
set +e
SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
bash "$SCRIPT_DIR/install_unix.sh" macos
STATUS=$?
printf '\nKurulum sona erdi. Bu pencereyi kapatmak için Return tuşuna basın.\n'
read -r _
exit "$STATUS"
