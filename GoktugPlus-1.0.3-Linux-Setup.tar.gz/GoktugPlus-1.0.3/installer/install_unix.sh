#!/usr/bin/env bash
# Goktug+ per-user installer for Linux and macOS.
set -euo pipefail

TARGET="${1:-auto}"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"

case "$(uname -s)" in
  Linux) HOST="linux" ;;
  Darwin) HOST="macos" ;;
  *) printf 'Bu kurucu Linux ve macOS içindir.\n' >&2; exit 1 ;;
esac
if [[ "$TARGET" != auto && "$TARGET" != "$HOST" ]]; then
  printf 'Bu kurulum dosyası %s için; mevcut sistem %s.\n' "$TARGET" "$HOST" >&2
  exit 1
fi

if [[ ! -d "$PROJECT_ROOT/src/goktug" || ! -f "$PROJECT_ROOT/pyproject.toml" ]]; then
  printf 'Goktug+ kaynakları bulunamadı. Kurucu dosyasını projenin tam klasör ağacında çalıştırın.\n' >&2
  exit 1
fi

PYTHON_BIN="$(command -v python3 || true)"
if [[ -z "$PYTHON_BIN" ]]; then
  printf 'Python 3 bulunamadı. Python 3.10 veya üzerini kurup kurulumu yeniden başlatın.\n' >&2
  printf 'Kurulum, sistem Python\x27una dokunmaz ve yönetici izni istemez.\n' >&2
  exit 1
fi
if ! "$PYTHON_BIN" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
  "$PYTHON_BIN" --version >&2 || true
  printf 'Goktug+ için Python 3.10 veya üzeri gerekiyor. Uyumlu sürümü kurup yeniden deneyin.\n' >&2
  exit 1
fi

if [[ "$HOST" == linux ]]; then
  DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
  [[ "$DATA_HOME" = /* ]] || DATA_HOME="$HOME/.local/share"
  APP_DIR="$DATA_HOME/goktug-plus"
else
  APP_DIR="$HOME/Library/Application Support/GoktugPlus"
fi
BIN_DIR="$HOME/.local/bin"

mkdir -p "$APP_DIR/src" "$BIN_DIR"
# Copy only Goktug+ program files; do not remove anything from an existing install.
cp -R "$PROJECT_ROOT/src/goktug" "$APP_DIR/src/"
cp "$PROJECT_ROOT/installer/trp.py" "$PROJECT_ROOT/installer/tpg.py" "$APP_DIR/"
cp "$PROJECT_ROOT/README.md" "$PROJECT_ROOT/LICENSE" "$APP_DIR/"

printf -v Q_PYTHON '%q' "$PYTHON_BIN"
printf -v Q_APP '%q' "$APP_DIR"
for command_name in trp tpg; do
  {
    printf '#!/usr/bin/env bash\n'
    printf 'PYTHON=%s\nAPP_DIR=%s\n' "$Q_PYTHON" "$Q_APP"
    if [[ "$command_name" == trp ]]; then
      printf 'exec "$PYTHON" "$APP_DIR/trp.py" "$@"\n'
    else
      printf 'exec "$PYTHON" "$APP_DIR/tpg.py" "$@"\n'
    fi
  } > "$BIN_DIR/$command_name"
  chmod 755 "$BIN_DIR/$command_name"
done

add_path_to_rc() {
  local rc_file="$1"
  local marker='# Goktug+ command path'
  mkdir -p "$(dirname -- "$rc_file")"
  if [[ ! -f "$rc_file" ]] || ! grep -Fq "$marker" "$rc_file"; then
    {
      printf '\n%s\n' "$marker"
      printf 'export PATH="$HOME/.local/bin:$PATH"\n'
    } >> "$rc_file"
  fi
}

SHELL_NAME="$(basename -- "${SHELL:-/bin/bash}")"
case "$SHELL_NAME" in
  zsh)
    add_path_to_rc "$HOME/.zprofile"
    add_path_to_rc "$HOME/.zshrc"
    ;;
  bash)
    add_path_to_rc "$HOME/.profile"
    add_path_to_rc "$HOME/.bashrc"
    ;;
  fish)
    FISH_CONF="$HOME/.config/fish/conf.d/goktug-plus.fish"
    mkdir -p "$(dirname -- "$FISH_CONF")"
    if [[ ! -f "$FISH_CONF" ]]; then
      printf '# Goktug+ command path\nfish_add_path "$HOME/.local/bin"\n' > "$FISH_CONF"
    fi
    ;;
  *)
    printf 'Otomatik PATH satırı %s için eklenmedi. Komutlar %s içindedir; PATH\x27e bu klasörü ekleyin.\n' "$SHELL_NAME" "$BIN_DIR"
    ;;
esac

printf '\nGoktug+ kuruldu (%s).\n' "$HOST"
printf 'Kurulum dizini: %s\nKomutlar: %s/trp ve %s/tpg\n' "$APP_DIR" "$BIN_DIR" "$BIN_DIR"
printf 'Yeni terminal açın veya bu oturum için: export PATH="$HOME/.local/bin:$PATH"\n'
printf 'Kontrol: trp --version  |  tpg --help\n'
