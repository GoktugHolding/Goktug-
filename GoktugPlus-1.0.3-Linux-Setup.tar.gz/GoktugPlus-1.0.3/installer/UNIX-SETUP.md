# Goktug+ Linux ve macOS kurucuları

Bu paketler `.deb`/`.pkg` veya imzalı uygulama bundle'ı değil; proje kaynaklarıyla birlikte çalışan, kullanıcı hesabına kurulum yapan shell kurucularıdır.

## Gereksinimler ve davranış

- Linux veya macOS
- Python 3.10 veya üzeri
- Yönetici izni gerekmez; sistem Python'ı değiştirilmez.
- `trp` ve `tpg`, `$HOME/.local/bin` altına; Goktug+ kaynak modülleri kullanıcı veri klasörüne kopyalanır.
- Bash/zsh başlangıç dosyalarına komut yolunu ekler. Kurulumdan sonra yeni terminal açın.
- `.tpg` dosyalarını çift tıklayarak çalıştırma ilişkisi bu shell kurucularına dahil değildir.
- Python bulunamazsa kurulum durur; kurucu Python'u otomatik indirmez.

## Linux

Arşivi açın, oluşan `GoktugPlus-1.0.3` klasörüne girin ve çalıştırın:

```bash
bash installer/GoktugPlus-Setup-Linux.sh
```

Ardından yeni terminal açıp doğrulayın:

```bash
trp --version
tpg --help
trp examples/merhaba.tpg
```

## macOS

ZIP'i açıp oluşan klasörde `GoktugPlus-Setup-macOS.command` dosyasına çift tıklayın. Terminal'den çalıştırmak isterseniz:

```bash
bash installer/install_unix.sh macos
```

İşlem bitince yeni terminal açın ve Linux bölümündeki komutlarla doğrulayın.

## Kurulum dizinleri

- Linux: `${XDG_DATA_HOME:-$HOME/.local/share}/goktug-plus`
- macOS: `$HOME/Library/Application Support/GoktugPlus`
- Komut sarmalayıcıları: `$HOME/.local/bin/trp` ve `$HOME/.local/bin/tpg`

Kurucu yalnızca kendi bilinen Goktug+ dosyalarını günceller; mevcut kurulum klasöründeki başka dosyaları topluca silmez. macOS akışı Linux üzerinde statik olarak kontrol edildi; gerçek macOS çalıştırma testi bu dağıtım ortamında yapılamadı.
