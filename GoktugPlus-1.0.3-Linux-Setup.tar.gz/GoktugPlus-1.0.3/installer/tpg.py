from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from goktug.package_manager import main

raise SystemExit(main())
