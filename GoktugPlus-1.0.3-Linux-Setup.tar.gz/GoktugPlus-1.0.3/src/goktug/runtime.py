"""Goktug+ kaynaklarını derleyip çalıştıran çalışma zamanı."""
from __future__ import annotations

import os
import sys
import tokenize
import traceback
from pathlib import Path

from .transpiler import translate

ERROR_NAMES = {
    "SyntaxError": "Sözdizimi Hatası", "IndentationError": "Girinti Hatası",
    "TokenError": "Sözdizimi Hatası",
    "TabError": "Girinti Hatası", "NameError": "İsim Hatası",
    "TypeError": "Tür Hatası", "ValueError": "Değer Hatası",
    "ZeroDivisionError": "Sıfıra Bölme Hatası", "IndexError": "Dizin Hatası",
    "KeyError": "Anahtar Hatası", "AttributeError": "Özellik Hatası",
    "FileNotFoundError": "Dosya Bulunamadı", "ImportError": "Modül Yükleme Hatası",
    "ModuleNotFoundError": "Modül Bulunamadı", "AssertionError": "Doğrulama Hatası",
    "RuntimeError": "Çalışma Hatası", "PermissionError": "İzin Hatası",
    "OSError": "İşletim Sistemi Hatası", "Exception": "Program Hatası",
}


def format_error(exc: BaseException, filename: str) -> str:
    """Python traceback'i göstermeden kaynak konumlu, Türkçe hata üretir."""
    label = ERROR_NAMES.get(type(exc).__name__, "Program Hatası")
    line = getattr(exc, "lineno", None)
    column = getattr(exc, "offset", None)
    if isinstance(exc, tokenize.TokenError) and len(exc.args) > 1:
        token_location = exc.args[1]
        if isinstance(token_location, tuple) and len(token_location) == 2:
            line, column = token_location
    if line is None:
        tb = traceback.extract_tb(exc.__traceback__)
        candidates = [frame for frame in tb if frame.filename == filename]
        if candidates:
            line = candidates[-1].lineno
    location = filename
    if line:
        location += f":{line}"
        if column:
            location += f":{column}"
    detail = "Program beklenmedik bir hatayla karşılaştı."
    if isinstance(exc, NameError):
        missing = getattr(exc, "name", None)
        detail = f"'{missing}' adlı ad veya değişken bulunamadı." if missing else "Kullanılan ad bulunamadı."
    elif isinstance(exc, tokenize.TokenError):
        detail = str(exc.args[0]) if exc.args else "Kaynak kod çözümlenemedi."
        detail = detail.replace("EOF in multi-line string", "çok satırlı metin sabiti tamamlanmadı")
        detail = detail.replace("EOF in multi-line statement", "kaynak dosyası beklenmedik yerde bitti")
    elif isinstance(exc, SyntaxError):
        syntax_messages = {
            "invalid syntax": "geçersiz sözdizimi",
            "unexpected indent": "beklenmeyen girinti",
            "expected an indented block": "girintili bir kod bloğu bekleniyordu",
            "expected ':'": "':' işareti bekleniyordu",
            "unexpected EOF while parsing": "kod tamamlanmadan dosya sonuna ulaşıldı",
            "unterminated string literal": "metin sabiti kapatılmamış",
        }
        detail = syntax_messages.get(exc.msg, "Kaynak kodda dilin yazım kurallarına uymayan bir ifade bulundu.")
    elif isinstance(exc, ModuleNotFoundError):
        name = getattr(exc, "name", None)
        detail = f"'{name}' adlı modül bulunamadı. Gerekli paketin kurulu olup olmadığını kontrol edin."
    elif isinstance(exc, FileNotFoundError):
        detail = "Belirtilen dosya veya klasör bulunamadı."
    elif isinstance(exc, PermissionError):
        detail = "Bu dosya veya kaynağa erişim izniniz yok."
    elif isinstance(exc, TypeError):
        detail = "Bu işlem, verilen değer türleri için desteklenmiyor."
    elif isinstance(exc, ValueError):
        detail = "Verilen değer bu işlem için uygun değil."
    elif isinstance(exc, ZeroDivisionError):
        detail = "Bir sayı sıfıra bölünemez."
    elif isinstance(exc, IndexError):
        detail = "İstenen konum, dizinin sınırları dışında."
    elif isinstance(exc, KeyError):
        detail = "İstenen anahtar sözlükte bulunamadı."
    elif isinstance(exc, AttributeError):
        detail = "Belirtilen özellik veya yöntem bu değerde bulunamadı."
    elif isinstance(exc, ImportError):
        detail = "Gerekli modül veya öğe yüklenemedi."
    elif isinstance(exc, AssertionError):
        detail = "Doğrulama koşulu sağlanmadı."
    elif isinstance(exc, OSError):
        detail = "İşletim sistemi bir dosya veya kaynak işlemini tamamlayamadı."
    return f"{label}:\n{location}\n\n{detail}"


def run_file(path: str | os.PathLike[str], argv: list[str] | None = None) -> int:
    """Bir .tpg dosyasını çalıştır. Başarıda 0, program hatasında 1 döndürür."""
    source_path = Path(path).expanduser().resolve()
    if not source_path.is_file():
        print(f"Dosya Bulunamadı:\n{path}\n\nBelirtilen kaynak dosya mevcut değil.", file=sys.stderr)
        return 2
    if source_path.suffix.lower() != ".tpg":
        print("Dosya Türü Hatası:\nGoktug+ kaynak dosyalarının uzantısı .tpg olmalıdır.", file=sys.stderr)
        return 2
    try:
        with tokenize.open(source_path) as handle:
            source = handle.read()
        translated = translate(source)
        code = compile(translated.source, str(source_path), "exec")
        namespace = {
            "__name__": "__main__", "__file__": str(source_path),
            "__package__": None, "__cached__": None,
        }
        sys.path.insert(0, str(source_path.parent))
        previous_argv = sys.argv[:]
        sys.argv = [str(source_path)] + (argv or [])
        try:
            exec(code, namespace, namespace)
        finally:
            sys.argv = previous_argv
            try:
                sys.path.remove(str(source_path.parent))
            except ValueError:
                pass
        return 0
    except KeyboardInterrupt:
        print("\nGoktug+ programı kullanıcı tarafından durduruldu.", file=sys.stderr)
        return 130
    except SystemExit as exc:
        if exc.code is None:
            return 0
        if isinstance(exc.code, int):
            return exc.code
        print("\nGoktug+ programı bir sonlandırma iletisiyle durduruldu.", file=sys.stderr)
        return 1
    except (Exception, tokenize.TokenError, IndentationError) as exc:
        print(format_error(exc, str(source_path)), file=sys.stderr)
        return 1
