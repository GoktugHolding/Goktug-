Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "StrFunc.nsh"
!include "WinMessages.nsh"
${Using:StrFunc} StrStr
${Using:StrFunc} StrRep
${Using:StrFunc} UnStrRep

Var PreviousInstallDir

Name "Goktug+ Setup Wizard"
Caption "Goktug+ Setup Wizard"
OutFile "GoktugPlusSetup.exe"
Icon "../installer/goktug_tpg_icon.ico"
UninstallIcon "../installer/goktug_tpg_icon.ico"
VIProductVersion "1.0.3.0"
VIAddVersionKey /LANG=1055 "CompanyName" "Goktug Software"
VIAddVersionKey /LANG=1055 "ProductName" "Goktug+ Setup Wizard"
VIAddVersionKey /LANG=1055 "FileDescription" "Goktug+ Kurulum Sihirbazi"
VIAddVersionKey /LANG=1055 "FileVersion" "1.0.3.0"
VIAddVersionKey /LANG=1055 "OriginalFilename" "GoktugPlusSetup.exe"
VIAddVersionKey /LANG=1055 "LegalCopyright" "Copyright 2026 Goktug Software"
VIAddVersionKey /LANG=1033 "CompanyName" "Goktug Software"
VIAddVersionKey /LANG=1033 "ProductName" "Goktug+ Setup Wizard"
VIAddVersionKey /LANG=1033 "FileDescription" "Goktug+ Setup Wizard"
VIAddVersionKey /LANG=1033 "FileVersion" "1.0.3.0"
VIAddVersionKey /LANG=1033 "OriginalFilename" "GoktugPlusSetup.exe"
VIAddVersionKey /LANG=1033 "LegalCopyright" "Copyright 2026 Goktug Software"
InstallDir "$LOCALAPPDATA\Programs\GoktugPlus"
InstallDirRegKey HKCU "Software\GoktugPlus" "InstallDir"
RequestExecutionLevel user

!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Goktug+ Setup Wizard"
!define MUI_WELCOMEPAGE_TEXT "Goktug+ bilgisayarınıza kurulacaktır.$\r$\n$\r$\nKomut İstemi'ni yeniden açtıktan sonra trp ve tpg komutlarını doğrudan kullanabilirsiniz.$\r$\n$\r$\nUyumlu Python 3.10+ bulunamazsa Setup, resmi Python 3.14.8 kurucusunu indirip Goktug+ klasörüne özel kurar; diğer Python kurulumlarına ve Python PATH ayarlarına dokunmaz. Goktug+ komutları için yalnızca uygulama klasörü kullanıcı PATH'ine eklenir. İlk kurulum için internet bağlantısı gerekir."
!define MUI_DIRECTORYPAGE_TEXT_TOP "Goktug+ dosyalarının kurulacağı klasörü seçin. Kurulum yalnızca bu kullanıcı hesabı için yapılır."
!define MUI_FINISHPAGE_TITLE "Goktug+ kurulumu tamamlandı"
!define MUI_FINISHPAGE_TEXT "Kurulum tamamlandı. PATH ayarının yüklenmesi için açık Komut İstemi pencerelerini kapatıp yeniden açın. Ardından trp --help komutunu deneyebilirsiniz."
!define MUI_FINISHPAGE_NOREBOOTSUPPORT

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "../LICENSE"
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE ValidateInstallDir
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Turkish"

Function .onInit
  ReadRegStr $PreviousInstallDir HKCU "Software\GoktugPlus" "InstallDir"
  ${StrStr} $0 "$INSTDIR\" "$PROGRAMFILES\"
  ${If} $0 != ""
    StrCpy $INSTDIR "$LOCALAPPDATA\Programs\GoktugPlus"
  ${EndIf}
  ${If} $PROGRAMFILES64 != ""
    ${StrStr} $0 "$INSTDIR\" "$PROGRAMFILES64\"
    ${If} $0 != ""
      StrCpy $INSTDIR "$LOCALAPPDATA\Programs\GoktugPlus"
    ${EndIf}
  ${EndIf}
FunctionEnd

Function ValidateInstallDir
  ${StrStr} $0 "$INSTDIR\" "$PROGRAMFILES\"
  ${If} $0 != ""
    MessageBox MB_ICONEXCLAMATION|MB_OK "Program Files klasörü yönetici izni gerektirir. Goktug+ Setup kullanıcı hesabınıza kurulur; lütfen önerilen kullanıcı klasörünü seçin."
    Abort
  ${EndIf}
  ${If} $PROGRAMFILES64 != ""
    ${StrStr} $0 "$INSTDIR\" "$PROGRAMFILES64\"
    ${If} $0 != ""
      MessageBox MB_ICONEXCLAMATION|MB_OK "Program Files klasörü yönetici izni gerektirir. Goktug+ Setup kullanıcı hesabınıza kurulur; lütfen önerilen kullanıcı klasörünü seçin."
      Abort
    ${EndIf}
  ${EndIf}
FunctionEnd

Function AddGoktugToPath
  ReadRegStr $0 HKCU "Environment" "Path"
  ${StrStr} $1 "$0" "$INSTDIR"
  ${If} $1 == ""
    ${If} $0 == ""
      StrCpy $0 "$INSTDIR"
    ${Else}
      StrCpy $0 "$0;$INSTDIR"
    ${EndIf}
    WriteRegExpandStr HKCU "Environment" "Path" "$0"
  ${EndIf}
  WriteRegStr HKCU "Software\GoktugPlus" "InstallDir" "$INSTDIR"
  SendMessage ${HWND_BROADCAST} ${WM_SETTINGCHANGE} 0 "STR:Environment" /TIMEOUT=5000
FunctionEnd

Function RemovePreviousGoktugFromPath
  ${If} $PreviousInstallDir != ""
  ${AndIf} $PreviousInstallDir != $INSTDIR
    ReadRegStr $0 HKCU "Environment" "Path"
    ${StrRep} $0 "$0" ";$PreviousInstallDir;" ";"
    ${StrRep} $0 "$0" "$PreviousInstallDir;" ""
    ${StrRep} $0 "$0" ";$PreviousInstallDir" ""
    ${If} $0 == "$PreviousInstallDir"
      StrCpy $0 ""
    ${EndIf}
    WriteRegExpandStr HKCU "Environment" "Path" "$0"
    SendMessage ${HWND_BROADCAST} ${WM_SETTINGCHANGE} 0 "STR:Environment" /TIMEOUT=5000
  ${EndIf}
FunctionEnd

Function AssociateTpgFiles
  ReadRegStr $0 HKCU "Software\Classes\.tpg" ""
  ${If} $0 != "GoktugPlus.Source"
    WriteRegStr HKCU "Software\GoktugPlus" "PreviousTpgProgId" "$0"
  ${EndIf}
  WriteRegStr HKCU "Software\Classes\.tpg" "" "GoktugPlus.Source"
  WriteRegStr HKCU "Software\Classes\GoktugPlus.Source" "" "Goktug+ Kaynak Dosyası"
  WriteRegStr HKCU "Software\Classes\GoktugPlus.Source" "FriendlyTypeName" "Goktug+ Kaynak Dosyası"
  WriteRegStr HKCU "Software\Classes\GoktugPlus.Source\DefaultIcon" "" "$INSTDIR\goktug_tpg_icon.ico,0"
  WriteRegStr HKCU "Software\Classes\GoktugPlus.Source\shell" "" "open"
  WriteRegStr HKCU "Software\Classes\GoktugPlus.Source\shell\open" "" "Goktug+ ile çalıştır"
  WriteRegStr HKCU "Software\Classes\GoktugPlus.Source\shell\open\command" "" '"$SYSDIR\cmd.exe" /k ""$INSTDIR\open_tpg.cmd" "%1""'
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'
FunctionEnd

Function EnsurePythonRuntime
  IfFileExists "$INSTDIR\runtime\python.exe" pythonRuntimeReady
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File /oname=detect_python.ps1 "../installer/detect_python.ps1"
  SetOutPath "$INSTDIR"
  nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$PLUGINSDIR\detect_python.ps1" -ConfigPath "$INSTDIR\python-config.cmd"'
  Pop $0
  Pop $1
  ${If} $0 == "0"
    Return
  ${EndIf}

  DetailPrint "Uyumlu bir çalışma ortamı bulunamadı; Python 3.14.8 indiriliyor."
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File /oname=download_python.ps1 "../installer/download_python.ps1"
  nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$PLUGINSDIR\download_python.ps1" -Destination "$PLUGINSDIR\python-installer.exe"'
  Pop $0
  Pop $1
  ${If} $0 != "0"
    DetailPrint "$1"
    MessageBox MB_ICONSTOP|MB_OK "Python indirilemedi veya doğrulanamadı. İnternet bağlantınızı kontrol edip kurulumu yeniden deneyin."
    Abort
  ${EndIf}

  DetailPrint "Python 3.14.8 Goktug+ klasörüne kuruluyor; sistem PATH'i değiştirilmeyecek."
  ExecWait '"$PLUGINSDIR\python-installer.exe" /quiet InstallAllUsers=0 TargetDir="$INSTDIR\runtime" Include_launcher=0 Include_pip=1 Include_test=0 Include_doc=0 Include_tcltk=0 Include_dev=1 PrependPath=0 AssociateFiles=0 Shortcuts=0' $0
  ${If} $0 != 0
    MessageBox MB_ICONSTOP|MB_OK "Çalışma ortamı kurulamadı. Hata kodu: $0"
    Abort
  ${EndIf}
  IfFileExists "$INSTDIR\runtime\python.exe" +2 0
    MessageBox MB_ICONSTOP|MB_OK "Kurulum doğrulaması başarısız oldu: özel çalışma ortamı bulunamadı."
    Abort

  SetOutPath "$PLUGINSDIR"
  File /oname=record_private_runtime.ps1 "../installer/record_private_runtime.ps1"
  nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$PLUGINSDIR\record_private_runtime.ps1" -RuntimePath "$INSTDIR\runtime" -ManifestPath "$INSTDIR\goktug-private-runtime.csv"'
  Pop $0
  Pop $1
  ${If} $0 != "0"
    DetailPrint "Özel çalışma ortamının dosya listesi kaydedilemedi; bu nedenle kaldırıcı bu ortamı silmeyecek."
    MessageBox MB_ICONEXCLAMATION|MB_OK "Özel çalışma ortamının güvenli kaldırma listesi oluşturulamadı. Güvenliğiniz için kaldırıcı bu dosyalara dokunmayacak."
  ${EndIf}
pythonRuntimeReady:
FunctionEnd

Section "Goktug+ (zorunlu)" SecGoktug
  SectionIn RO
  Call EnsurePythonRuntime
  SetOutPath "$INSTDIR"
  File "../installer/trp.cmd"
  File "../installer/tpg.cmd"
  File "../installer/open_tpg.cmd"
  File "../installer/trp.py"
  File "../installer/tpg.py"
  File "../installer/remove_private_runtime.ps1"
  File "../installer/goktug_tpg_icon.ico"
  File "../README.md"
  File "../LICENSE"

  SetOutPath "$INSTDIR/src/goktug"
  File "../src/goktug/*.py"

  SetOutPath "$INSTDIR/examples"
  File "../examples/*.tpg"

  SetOutPath "$INSTDIR"
  WriteUninstaller "$INSTDIR/Uninstall.exe"
  Call RemovePreviousGoktugFromPath
  Call AddGoktugToPath
  Call AssociateTpgFiles

  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GoktugPlus" "DisplayName" "Goktug+ 1.0.3"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GoktugPlus" "DisplayVersion" "1.0.3"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GoktugPlus" "Publisher" "Goktug Software"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GoktugPlus" "UninstallString" '"$INSTDIR/Uninstall.exe"'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GoktugPlus" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GoktugPlus" "NoRepair" 1
SectionEnd

Function un.RemoveGoktugFromPath
  ReadRegStr $0 HKCU "Environment" "Path"
  ${UnStrRep} $0 "$0" ";$INSTDIR" ""
  ${UnStrRep} $0 "$0" "$INSTDIR;" ""
  ${UnStrRep} $0 "$0" "$INSTDIR" ""
  WriteRegExpandStr HKCU "Environment" "Path" "$0"
  ReadRegStr $1 HKCU "Software\Classes\.tpg" ""
  ${If} $1 == "GoktugPlus.Source"
    ReadRegStr $2 HKCU "Software\GoktugPlus" "PreviousTpgProgId"
    ${If} $2 == ""
      DeleteRegValue HKCU "Software\Classes\.tpg" ""
      DeleteRegKey /ifempty HKCU "Software\Classes\.tpg"
    ${Else}
      WriteRegStr HKCU "Software\Classes\.tpg" "" "$2"
    ${EndIf}
  ${EndIf}
  DeleteRegKey HKCU "Software\Classes\GoktugPlus.Source"
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'
  DeleteRegKey HKCU "Software\GoktugPlus"
  SendMessage ${HWND_BROADCAST} ${WM_SETTINGCHANGE} 0 "STR:Environment" /TIMEOUT=5000
FunctionEnd

Section "Uninstall"
  Call un.RemoveGoktugFromPath
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\GoktugPlus"
  IfFileExists "$INSTDIR\remove_private_runtime.ps1" 0 skipPrivateRuntimeCleanup
    nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\remove_private_runtime.ps1" -RuntimePath "$INSTDIR\runtime" -ManifestPath "$INSTDIR\goktug-private-runtime.csv"'
    Pop $0
    Pop $1
skipPrivateRuntimeCleanup:
  Delete "$INSTDIR\trp.cmd"
  Delete "$INSTDIR\tpg.cmd"
  Delete "$INSTDIR\open_tpg.cmd"
  Delete "$INSTDIR\trp.py"
  Delete "$INSTDIR\tpg.py"
  Delete "$INSTDIR\python-config.cmd"
  Delete "$INSTDIR\remove_private_runtime.ps1"
  Delete "$INSTDIR\goktug-private-runtime.csv"
  Delete "$INSTDIR\goktug_tpg_icon.ico"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\LICENSE"
  Delete "$INSTDIR\Uninstall.exe"
  Delete "$INSTDIR\src\goktug\__init__.py"
  Delete "$INSTDIR\src\goktug\__main__.py"
  Delete "$INSTDIR\src\goktug\arguments.py"
  Delete "$INSTDIR\src\goktug\cli.py"
  Delete "$INSTDIR\src\goktug\mappings.py"
  Delete "$INSTDIR\src\goktug\package_manager.py"
  Delete "$INSTDIR\src\goktug\runtime.py"
  Delete "$INSTDIR\src\goktug\transpiler.py"
  Delete "$INSTDIR\examples\asenkron.tpg"
  Delete "$INSTDIR\examples\hatalar_dosyalar.tpg"
  Delete "$INSTDIR\examples\hesap_makinesi.tpg"
  Delete "$INSTDIR\examples\hesaplama.tpg"
  Delete "$INSTDIR\examples\ileri.tpg"
  Delete "$INSTDIR\examples\matematik_json.tpg"
  Delete "$INSTDIR\examples\merhaba.tpg"
  Delete "$INSTDIR\examples\siniflar.tpg"
  RMDir "$INSTDIR\src\goktug"
  RMDir "$INSTDIR\src"
  RMDir "$INSTDIR\examples"
  RMDir "$INSTDIR\runtime"
  RMDir "$INSTDIR"
SectionEnd
