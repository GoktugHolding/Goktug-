#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
command -v makensis >/dev/null || { echo "NSIS (makensis) kurulu değil." >&2; exit 1; }
makensis installer/goktug-plus.nsi
