param(
    [Parameter(Mandatory = $true)]
    [string]$ConfigPath
)

$ErrorActionPreference = 'SilentlyContinue'

function Write-LauncherConfig([string]$launcher) {
    $content = "@echo off`r`nset GOKTUG_PYTHON_LAUNCHER=$launcher`r`n"
    [System.IO.File]::WriteAllText($ConfigPath, $content, [System.Text.Encoding]::ASCII)
}

function Is-CompatibleVersion([string]$versionText) {
    if ($versionText -match '(?:^|\D)3\.(\d+)(?:\D|$)') {
        return ([int]$Matches[1] -ge 10)
    }
    return $false
}

# `py -0p` only lists registered runtimes; unlike `py -3` in the install
# manager, it does not install a missing runtime as a side effect.
$launcherCommand = Get-Command py.exe -ErrorAction SilentlyContinue
if ($launcherCommand) {
    $installed = @(& $launcherCommand.Source -0p 2>$null)
    foreach ($line in $installed) {
        if (Is-CompatibleVersion ([string]$line)) {
            Write-LauncherConfig 'py -3'
            exit 0
        }
    }
}

# A traditional install may expose python.exe without registering a launcher.
# Do not execute the WindowsApps alias: Python Install Manager may install a
# runtime when that alias is launched and no runtime is present.
$pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
if ($pythonCommand -and $pythonCommand.Source -notmatch '\\WindowsApps\\') {
    $version = @(& $pythonCommand.Source -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>$null)
    if ($LASTEXITCODE -eq 0 -and (Is-CompatibleVersion ([string]($version -join ' ')))) {
        Write-LauncherConfig 'python'
        exit 0
    }
}

exit 1
