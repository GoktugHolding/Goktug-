param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimePath,
    [Parameter(Mandatory = $true)]
    [string]$ManifestPath
)

$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath($RuntimePath).TrimEnd('\') + '\'
if (-not [System.IO.Directory]::Exists($root)) {
    throw 'Özel çalışma ortamı klasörü bulunamadı.'
}

$rows = @(
    Get-ChildItem -LiteralPath $root -File -Force -Recurse | ForEach-Object {
        [pscustomobject]@{
            Path = $_.FullName.Substring($root.Length)
            SHA256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        }
    }
)
$rows | Export-Csv -LiteralPath $ManifestPath -NoTypeInformation -Encoding UTF8
