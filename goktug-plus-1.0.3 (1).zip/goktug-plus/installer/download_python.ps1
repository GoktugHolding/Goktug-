param(
    [Parameter(Mandatory = $true)]
    [string]$Destination
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if ([Environment]::Is64BitOperatingSystem) {
    $uri = 'https://www.python.org/ftp/python/3.14.8/python-3.14.8-amd64.exe'
    $expectedSha256 = '759be887b96e736a3ca886daf8d575f18fcae1a09efab6902f42d59e8999f8ef'
}
else {
    $uri = 'https://www.python.org/ftp/python/3.14.8/python-3.14.8.exe'
    $expectedSha256 = '963def30c7ebc6381a1ee9056d251ddc4520b18391da2cf0602cfb58f5b80568'
}

try {
    Invoke-WebRequest -Uri $uri -OutFile $Destination -UseBasicParsing

    $actualSha256 = (Get-FileHash -Path $Destination -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha256 -ne $expectedSha256) {
        throw 'İndirilen kurulum dosyasının SHA-256 doğrulaması başarısız oldu.'
    }

    $signature = Get-AuthenticodeSignature -FilePath $Destination
    if ($signature.Status -ne [System.Management.Automation.SignatureStatus]::Valid) {
        throw 'İndirilen kurulum dosyasının dijital imzası doğrulanamadı.'
    }
}
catch {
    Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}

exit 0
