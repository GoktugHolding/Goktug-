"""Üretilen PNG işaretini Windows için çok çözünürlüklü ICO'ya dönüştürür.

Geliştirici gereksinimi: Pillow (python -m pip install Pillow).
"""
from pathlib import Path
from PIL import Image

HERE = Path(__file__).resolve().parent
source = HERE / "goktug_tpg_icon.png"
target = HERE / "goktug_tpg_icon.ico"

with Image.open(source) as image:
    image.convert("RGBA").save(
        target,
        format="ICO",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
print(f"Windows simgesi oluşturuldu: {target}")
