@echo off
cd /d "%~dp0.."
makensis installer\goktug-plus.nsi
if errorlevel 1 exit /b %ERRORLEVEL%
echo Setup dosyasi: installer\GoktugPlusSetup.exe
