param(
    [Parameter(Mandatory = $true)]
    [string]$RuntimePath,
    [Parameter(Mandatory = $true)]
    [string]$ManifestPath
)

$ErrorActionPreference = 'SilentlyContinue'
if (-not [System.IO.File]::Exists($ManifestPath)) {
    exit 0
}

$root = [System.IO.Path]::GetFullPath($RuntimePath).TrimEnd('\') + '\'
if (-not [System.IO.Directory]::Exists($root)) {
    exit 0
}

$entries = Import-Csv -LiteralPath $ManifestPath
foreach ($entry in $entries) {
    try {
        $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($root, $entry.Path))
        if (-not $target.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) {
            continue
        }
        if ([System.IO.File]::Exists($target)) {
            $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($hash -eq $entry.SHA256) {
                Remove-Item -LiteralPath $target -Force
            }
        }
    }
    catch {
        # Keep any locked, changed, or otherwise inaccessible user data.
    }
}

$directories = @(Get-ChildItem -LiteralPath $root -Directory -Force -Recurse | Sort-Object { $_.FullName.Length } -Descending)
foreach ($directory in $directories) {
    try {
        if (@(Get-ChildItem -LiteralPath $directory.FullName -Force).Count -eq 0) {
            Remove-Item -LiteralPath $directory.FullName -Force
        }
    }
    catch {
        # Non-empty or inaccessible directories are deliberately preserved.
    }
}

try {
    if (@(Get-ChildItem -LiteralPath $root -Force).Count -eq 0) {
        Remove-Item -LiteralPath $root -Force
    }
}
catch {
    # Preserve anything that remains.
}
