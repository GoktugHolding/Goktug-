@echo off
setlocal
if "%~1"=="" goto missing_file
if not exist "%~f1" goto missing_file
pushd "%~dp1"
if errorlevel 1 goto directory_error
call "%~dp0trp.cmd" "%~f1"
set "GOKTUG_EXIT_CODE=%ERRORLEVEL%"
popd
exit /b %GOKTUG_EXIT_CODE%
:missing_file
echo Goktug+ kaynak dosyasi bulunamadi.
exit /b 2
:directory_error
echo Kaynak dosyasinin bulundugu klasore gecilemedi.
exit /b 2
