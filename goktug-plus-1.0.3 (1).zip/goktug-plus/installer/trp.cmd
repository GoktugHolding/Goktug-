@echo off
setlocal
if exist "%~dp0runtime\python.exe" goto runlocal
if exist "%~dp0python-config.cmd" call "%~dp0python-config.cmd"
if defined GOKTUG_PYTHON_LAUNCHER goto runsystem
echo Goktug+ icin uyumlu bir calisma ortami bulunamadi. Setup Wizard'i yeniden calistirin. 1>&2
exit /b 9009
:runlocal
"%~dp0runtime\python.exe" "%~dp0trp.py" %*
exit /b %ERRORLEVEL%
:runsystem
%GOKTUG_PYTHON_LAUNCHER% "%~dp0trp.py" %*
exit /b %ERRORLEVEL%
