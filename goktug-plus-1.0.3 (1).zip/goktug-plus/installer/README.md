# Goktug+ Setup Wizard

`GoktugPlusSetup.exe`, Windows için kullanıcı profiline kurulan NSIS sihirbazıdır. Bu sürüm Goktug+ 1.0.3'ü kurar. Windows 10/11 ve internet bağlantısı yalnızca uyumlu Python bulunmadığında gerekir.

Önceki sürüm `C:\Program Files\GoktugPlus` altına kurulmuşsa bu Setup korumalı klasöre yazmayı denemez; hedefi `%LOCALAPPDATA%\Programs\GoktugPlus` olarak değiştirir ve eski kurulum yolunu kullanıcı PATH'inden kaldırır. Klasör seçiminde `Program Files` seçilirse kurulumdan önce açıklayıcı uyarı verir. Önceki `Program Files` dosyaları, yönetici izni olmadan değiştirilmemek veya silinmemek için olduğu yerde kalır.

## Python çalışma ortamı

Kurucu kurulu sürümleri önce `py -0p` ile listeler; ayrıca WindowsApps dışındaki normal `python.exe` kurulumunu sınar. Bu denetim, boş Python Install Manager'ın ilk çalıştırmada otomatik olarak genel bir runtime indirmesini tetiklemez. Uyumlu Python 3.10+ varsa kurucu `python-config.cmd` içine mevcut `py -3` veya `python` başlatıcısını kaydeder; mevcut kurulumlara dokunmaz. Uyumlu sürüm yoksa Python 3.14.8'in resmi Windows kurucusunu python.org'dan indirir, resmî SHA-256 ve Authenticode imzasını doğrular, sonra yalnızca `%LOCALAPPDATA%\Programs\GoktugPlus\runtime` altına sessizce kurar. Bu işlem `py` başlatıcısını veya Python'un PATH ayarlarını değiştirmez. `trp` ve `tpg` komutlarını doğrudan CMD'den açabilmek için yalnızca Goktug+ uygulama klasörü kullanıcı PATH'ine eklenir. İndirme/kurulum başarısız olursa Setup hata vererek devam etmez.

`trp.cmd` ve `tpg.cmd` önce Goktug+ klasöründeki özel yorumlayıcıyı, yoksa kurulum sırasında seçilen `python-config.cmd` başlatıcısını kullanır. Böylece başka Python sürümleri üzerine yazılmaz.

## Seçici kaldırma

Kaldırıcı artık kurulum klasörünü `/r` ile silmez. Yalnızca Setup'ın kopyaladığı bilinen Goktug+ dosyalarını ve boş kalan klasörleri kaldırır. Özel runtime ilk kurulumda SHA-256 manifestiyle kaydedilir; kaldırma yalnızca hash'i değişmemiş, manifestteki dosyaları siler. Sonradan eklenmiş paketler, değiştirilmiş runtime dosyaları ve kurulum klasörüne eklediğiniz başka içerikler korunur. Bu tür dosyalar kalırsa kurulum klasörü de silinmeden bırakılır. Eski kurulumdan manifesti olmayan bir runtime güvenli tarafta kalınarak korunur.

## Windows dosyası ve yayımlayıcı bilgisi

Kurulum `.tpg` uzantısını `Goktug+ Kaynak Dosyası` olarak kaydeder, kırmızı X'li `goktug_tpg_icon.ico` simgesini atar ve Explorer'a ilişkilendirme değişikliğini bildirir. Varsayılan `Open` eylemi `open_tpg.cmd` aracılığıyla dosyanın bulunduğu klasöre geçer ve `trp` ile çalıştırır; sonuçları görebilmeniz için açılan CMD penceresi kapanmaz. Kaldırıcı önceki kullanıcı düzeyindeki `.tpg` ilişkilendirmesini geri yükler.

Setup EXE dosyasının simgesi aynı kırmızı X'tir. Dosya sürüm kaynaklarında ve Windows'un yüklü uygulamalar kaydında `Goktug Software` yayımlayıcı/şirket bilgisi bulunur. Ancak bu metadata dijital kod imzası değildir. EXE bu kaynak koduyla imzalanmadığı için SmartScreen uyarısı çıkabilir; doğrulanmış yayımlayıcı için geçerli kod imza sertifikası ve itibar gerekir.

## EXE'yi yeniden üretme

NSIS 3.x gerekir. Proje kökünden Windows'ta `installer\build_windows_setup.bat`, Linux'ta `./installer/build_windows_setup.sh` çalıştırın. Sonuç `installer/GoktugPlusSetup.exe` olur. Yeniden derlemeden önce `python installer/build_icon.py` komutuyla (Pillow gerekir) çok boyutlu ICO'yu PNG kaynağından üretebilirsiniz.
